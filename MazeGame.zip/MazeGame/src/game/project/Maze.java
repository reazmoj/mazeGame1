package game.project;

import java.util.Scanner;
//this project is maze game in consul
public class Maze  {

    public static void main(String[] args) {

            int[][] maze =
                    {       {0,0,1,1,1,1,1,1,1,1,1,1,1},
                            {1,0,1,0,1,0,1,0,0,0,0,0,1},
                            {1,0,1,0,0,0,1,0,1,1,1,0,1},
                            {1,0,0,0,1,1,1,0,0,0,0,0,1},
                            {1,0,1,0,0,0,0,0,1,1,1,0,1},
                            {1,0,1,0,1,1,1,0,1,0,0,0,1},
                            {1,0,1,0,1,0,0,0,1,1,1,0,1},
                            {1,0,1,0,1,1,1,0,1,0,1,0,1},
                            {1,0,0,0,0,0,0,0,0,0,0,0,0},
                            {1,1,1,1,1,1,1,1,1,1,1,1,1}

                    };
            int col = 0;
            int row = 0;
            int cursor;


            while (col != 10 && row != 13) {
                for (int i = 0; i < 10; i++) {
                    for (int j = 0; j < 13; j++)
                        if (maze[i][j] == 0) {
                            if (row == i && col == j)
                                System.out.print("*");
                            else
                                System.out.print(" ");
                        } else if (maze[i][j] == 1) {
                            if (row == i && col == j)
                                System.out.print("*");
                            else
                                System.out.print("?");
                if (col == 13 && row == 10)
                    System.out.println("Error! This is wall");
                        }
                    System.out.println();
                }

                // define movement keys
                Scanner reader = new Scanner(System.in);  //define movement keys
                cursor = reader.nextInt();
                if (cursor == 8)
                    if (row < 10 && maze[row-1][col] == 0)
                        row--;
                if (cursor == 2)
                    if (col > 0 && maze[row+1][col] == 0)
                        row++;
                if (cursor == 6)
                    if (row < 10 && maze[row][col+1] ==0)
                        col++;
                if (cursor == 4)
                    if (row > 0 && maze[row][col-1] == 0)
                        col--;

            }
        }
    }


